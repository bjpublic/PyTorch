# 딥러닝에 목마른 사람들을 위한 PyTorch

"딥러닝에 목마른 사람들을 위한 PyTorch" 학습 GitHub 입니다.

## 필요 패키지

```
pytorch >= 1.0.0
torchvision >= 0.2.0
numpy
matplotlib
```

